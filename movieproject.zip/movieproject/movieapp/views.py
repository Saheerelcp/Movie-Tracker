from django.shortcuts import redirect, render
from django.http import HttpResponse, JsonResponse
from movieapp.models import user
import requests
# Create your views here.
def login(request):
    return render(request,"login.html")
def loginpost(request):
    username = request.POST['username']
    password = request.POST['password']
    
    try:
        us = user.objects.get(username=username)
        print('what is us',us)
        if username == us.username :
            print(password,'password')
            print('database passoword',us.password)
            if password ==us.password :
                return HttpResponse('successfull login')
            else:
                return render(request,'login.html',{'message':'Incorrect password'})
    except Exception:
        return render(request,'login.html',{'message':'No user exist'})

def register(request):
    return render(request,'register.html')
def registerpost(request):
    username = request.POST['username']
    password = request.POST['password1']
    obj = user()
    obj.username = username
    obj.password = password
    obj.save()
    return redirect('/login')
def home(request):
    return render(request,'home.html')

def search_movie(request):
    query = request.GET.get('query')
    if not query:
        return JsonResponse({'results': []})

    api_key = 'c61b2f1'  #http://www.omdbapi.com/?i=tt3896198&apikey=c61b2f1
    url =  f'http://www.omdbapi.com/?apikey={api_key}&s={query}'
    response = requests.get(url)
    return JsonResponse(response.json())