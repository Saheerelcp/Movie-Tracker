from django.urls import path
from movieapp.views import login,register,registerpost,loginpost,home,search_movie

urlpatterns= [
    path('login',login),
    path('register',register),
    path('registerpost',registerpost),
    path('loginpost',loginpost),
    path('home',home),
    path('search/',search_movie,name='search_movie')
]