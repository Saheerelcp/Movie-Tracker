function searchMovie() {
    const query = document.getElementById('searchBox').value;
    if (!query) {
        alert("Please enter a movie name");
        return;
    }

     fetch(`/search/?query=${query}`)
    .then(response => response.json())
    .then(data => {
      const movies = data.Search || [];  // Important!
      displayMovies(movies);             // Uses the same neon layout
    })
    .catch(error => console.error('Error:', error));
}

function displayMovies(movies) {
  const container = document.getElementById("movie-list");
  container.innerHTML = "";

  if (movies.length === 1) {
    container.classList.add("single-card");
  } else {
    container.classList.remove("single-card");
  }

  if (movies.length === 0) {
    container.innerHTML = '<p class="text-white ms-3">No results found.</p>';
    return;
  }

  movies.forEach((movie) => {
    const div = document.createElement("div");
    div.classList.add("col-sm-6", "col-md-4", "col-lg-3", "mb-4");

    div.innerHTML = `
      <div class="card h-100">
        <img src="${
          movie.Poster !== "N/A"
            ? movie.Poster
            : "https://via.placeholder.com/300x400?text=No+Image"
        }" class="card-img-top" alt="${movie.Title}">
        <div class="card-body d-flex flex-column">
          <h5 class="card-title">${movie.Title}</h5>
          <p class="card-text"><strong>Year:</strong> ${movie.Year}</p>
          <a href="#" class="btn btn-danger mt-auto">Add to List</a>
        </div>
      </div>
    `;

    container.appendChild(div);
  });
}
